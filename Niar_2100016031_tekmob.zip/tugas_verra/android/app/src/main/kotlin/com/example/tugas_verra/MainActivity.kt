package com.example.tugas_verra

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
